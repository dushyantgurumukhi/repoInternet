from fastapi import FastAPI, HTTPException
from typing import Any, Dict
import threading

app = FastAPI()

# Dictionary to store running threads
running_threads = {}

# Dictionary to store the termination flag for each thread
termination_flags = {}

def programCaller(thread_id):
    # Simulate a long-running process
    while not termination_flags.get(thread_id):
        print("Thread started -- in function programCaller: -- ", thread_id)
        pass

@app.post("/execute/DYNTUB_Program", response_model=Any)
async def DYNTUB_DT_Program():
    thread_id = len(running_threads) + 1
    termination_flags[thread_id] = False
    thread = threading.Thread(target=programCaller, args=(thread_id,))
    thread.start()
    running_threads[thread_id] = thread
    return {"thread_id": thread_id}

@app.post("/execute/killThread/", response_model=Any)
async def kill_running_thread(thread_id: dict):
    thisThreadId = thread_id.get("thread_id")

    if thisThreadId in running_threads:
        termination_flags[thisThreadId] = True  # Signal the thread to stop
        running_threads[thisThreadId].join()  # Wait for the thread to finish
        del running_threads[thisThreadId]
        return f"Thread {thisThreadId} has been terminated."
    else:
        return "Thread does not exist or is already completed."

@app.get("/execute/getallthreads/", response_model=Dict[int, str])
async def get_all_running_threads():
    thread_info = {}
    for thread_id, thread in running_threads.items():
        if thread.is_alive():
            thread_info[thread_id] = "Running"
        else:
            thread_info[thread_id] = "Completed"
    return thread_info    

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
