from fastapi import FastAPI, HTTPException
from typing import Any, Dict
import multiprocessing
import os

app = FastAPI()

# Dictionary to store running processes
running_processes = {}

def programCaller(process_id):
    # Simulate a long-running process
    while True:
        print("Process started -- in function programCaller : -- ",process_id)
        pass

@app.post("/execute/DYNTUB_Program", response_model=Any)
async def DYNTUB_DT_Program():
    process_id = len(running_processes) + 1
    process = multiprocessing.Process(target=programCaller, args=(process_id,))
    process.start()
    running_processes[process_id] = process
    return {"process_id": process_id}


@app.post("/execute/killProcess/", response_model=Any)
async def kill_running_process(process_id: dict):
    thisProcessId = process_id.get("process_id")

    if thisProcessId in running_processes:
        process = running_processes[thisProcessId]
        process.terminate()
        process.join()
        del running_processes[thisProcessId]
        return f"Process {thisProcessId} has been terminated."
    else:
        return "Process does not exist or is already completed."

@app.get("/execute/getallprocess/", response_model=Dict[int, str])
async def get_all_running_processes():
    process_info = {}
    for process_id, process in running_processes.items():
        if process.is_alive():
            process_info[process_id] = "Running"
        else:
            process_info[process_id] = "Completed"
    return process_info    

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
